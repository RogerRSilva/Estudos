﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Ordenacao
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] cvrValores = new int [1];
            string vlrInserido;

            bool fimNotas = false;
            bool vrfNota = false;

            do
            {
                for (int ii = 0; ii < cvrValores.Length; ii++)
                {
                    do
                    {
                        Console.WriteLine("Insira a nota: ");
                        vlrInserido = Console.ReadLine();
                   
                        if (int.TryParse(vlrInserido, out int numero))
                        {
                            cvrValores[ii] = int.Parse(vlrInserido);
                            vrfNota = true;
                        }
                        else
                        {
                            vrfNota = false;
                            Console.WriteLine("Insira um valor valido.");
                        }
                    }while(vrfNota == false);

                    bool opcValida = false;

                    do
                    {

                        Console.WriteLine("Adicionar nova nota? (Digite 1 ou 2)");
                        Console.WriteLine("1. Sim");
                        Console.WriteLine("2. Não");
                        Console.WriteLine();

                        string resp = Console.ReadLine();
                        if (int.TryParse(resp, out int valor))
                        {
                            if (valor == 1)
                            {
                                opcValida = true;
                                fimNotas = false;
                                cvrValores = AdicionarElemento(cvrValores, cvrValores[ii]);
                            }
                            else if (valor == 2)
                            {
                                opcValida = true;
                                fimNotas = true;
                                fimNotas = true;
                            }
                        }
                        else
                        {
                            Console.WriteLine("Opção inexistente");
                            opcValida = false;
                        }
                    } while (opcValida == false);
                }
            } while (fimNotas != true); 

            Console.WriteLine("Notas inseridas!");
            Console.ReadKey();

            InsertionSort(cvrValores, cvrValores.Length);

            Console.WriteLine("Os valores inseridos em ordem crescente é: ");
            for (int y = 0; y < cvrValores.Length; y++)
            {
                Console.WriteLine("");
                Console.WriteLine(cvrValores[y]);
            }
            Console.ReadKey();
            
        }

        // Método para adicionar um elemento a um array dinâmico
        static int[] AdicionarElemento(int[] array, int elemento)
        {
            int[] novoArray = new int[array.Length + 1];
            for (int i = 0; i < array.Length; i++)
            {
                novoArray[i] = array[i];
            }
            novoArray[array.Length] = elemento;
            return novoArray;
        }


        static void InsertionSort(int[] v, int n) // 'n' é o tamanho do vetor
        {
            int i = 0; // Inicializa o índice 'i'
            int j = 1; // Inicializa o índice 'j'
            int aux = 0; // Variável auxiliar para armazenar o elemento a ser inserido

            while (j < n) // Enquanto 'j' for menor que o tamanho do vetor
            {
                aux = v[j]; // Armazena o valor de v[j] em 'aux'
                i = j - 1; // Inicializa 'i' com o índice anterior a 'j'

                // Enquanto 'i' for válido e o elemento atual for maior que 'aux'
                while ((i >= 0) && (v[i] > aux))
                {
                    v[i + 1] = v[i]; // Move o elemento atual para a próxima posição
                    i = i - 1; // Decrementa 'i'
                }

                v[i + 1] = aux; // Insere 'aux' na posição correta
                j = j + 1; // Incrementa 'j' para avançar para o próximo elemento
            }
        }
    }
}
