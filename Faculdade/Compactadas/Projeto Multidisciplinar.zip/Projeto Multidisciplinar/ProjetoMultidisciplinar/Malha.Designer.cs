﻿namespace TesteGrafico
{
    partial class Malha
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(286, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Defina a quantidade de malhas no circuito:";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(435, 14);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(80, 25);
            this.button1.TabIndex = 2;
            this.button1.Text = "Confirmar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(307, 16);
            this.comboBox1.MaxDropDownItems = 4;
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 21;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(435, 235);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(80, 25);
            this.button2.TabIndex = 19;
            this.button2.Text = "Calcular";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(263, 235);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(80, 25);
            this.button3.TabIndex = 20;
            this.button3.Text = "Sair";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.Location = new System.Drawing.Point(13, 235);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(164, 12);
            this.label71.TabIndex = 22;
            this.label71.Text = "*Caso não vá utilizar todos os campos ";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.Location = new System.Drawing.Point(13, 247);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(129, 12);
            this.label72.TabIndex = 23;
            this.label72.Text = "  apenas deixe com o valor \"0\".";
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(349, 235);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(80, 25);
            this.button4.TabIndex = 24;
            this.button4.Text = "Limpar";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label2.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(135, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 18);
            this.label2.TabIndex = 5;
            this.label2.Text = "I1";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(164, 17);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(44, 24);
            this.textBox1.TabIndex = 6;
            this.textBox1.Text = "0";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(287, 17);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(44, 24);
            this.textBox2.TabIndex = 8;
            this.textBox2.Text = "0";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(224, 20);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(18, 18);
            this.label42.TabIndex = 9;
            this.label42.Text = "+";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label43.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(258, 20);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(25, 18);
            this.label43.TabIndex = 10;
            this.label43.Text = "I2";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label43);
            this.groupBox1.Controls.Add(this.label42);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(15, 45);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(500, 52);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Insira os valores:";
            this.groupBox1.Visible = false;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(105, 56);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(44, 24);
            this.textBox4.TabIndex = 6;
            this.textBox4.Text = "0";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(105, 26);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(44, 24);
            this.textBox3.TabIndex = 8;
            this.textBox3.Text = "0";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(265, 56);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(44, 24);
            this.textBox6.TabIndex = 10;
            this.textBox6.Text = "0";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(265, 26);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(44, 24);
            this.textBox5.TabIndex = 12;
            this.textBox5.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label5.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(74, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(24, 18);
            this.label5.TabIndex = 11;
            this.label5.Text = "I1";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(430, 56);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(44, 24);
            this.textBox8.TabIndex = 14;
            this.textBox8.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(181, 29);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(18, 18);
            this.label4.TabIndex = 12;
            this.label4.Text = "+";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(429, 26);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(44, 24);
            this.textBox7.TabIndex = 16;
            this.textBox7.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label3.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(234, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(25, 18);
            this.label3.TabIndex = 13;
            this.label3.Text = "I2";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label8.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(73, 59);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(25, 18);
            this.label8.TabIndex = 17;
            this.label8.Text = "I4";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(181, 56);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(18, 18);
            this.label7.TabIndex = 18;
            this.label7.Text = "+";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label6.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(234, 59);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(25, 18);
            this.label6.TabIndex = 19;
            this.label6.Text = "I5";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(343, 29);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(18, 18);
            this.label44.TabIndex = 21;
            this.label44.Text = "+";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label9.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(398, 29);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(25, 18);
            this.label9.TabIndex = 22;
            this.label9.Text = "I3";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(343, 59);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(18, 18);
            this.label46.TabIndex = 23;
            this.label46.Text = "+";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label45.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(398, 59);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(26, 18);
            this.label45.TabIndex = 24;
            this.label45.Text = "I6";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label45);
            this.groupBox2.Controls.Add(this.label46);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label44);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.textBox7);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.textBox8);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.textBox5);
            this.groupBox2.Controls.Add(this.textBox6);
            this.groupBox2.Controls.Add(this.textBox3);
            this.groupBox2.Controls.Add(this.textBox4);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(15, 45);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(500, 91);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Insira os valores:";
            this.groupBox2.Visible = false;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label37.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(149, 26);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(25, 18);
            this.label37.TabIndex = 31;
            this.label37.Text = "I2";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label36.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(19, 56);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(25, 18);
            this.label36.TabIndex = 34;
            this.label36.Text = "I5";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label39.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(20, 26);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(24, 18);
            this.label39.TabIndex = 28;
            this.label39.Text = "I1";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label14.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(149, 56);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(26, 18);
            this.label14.TabIndex = 36;
            this.label14.Text = "I6";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label12.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(279, 26);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(25, 18);
            this.label12.TabIndex = 38;
            this.label12.Text = "I3";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label10.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(278, 56);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(25, 18);
            this.label10.TabIndex = 40;
            this.label10.Text = "I7";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label54.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(141, 86);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(34, 18);
            this.label54.TabIndex = 47;
            this.label54.Text = "I10";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label52.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(408, 26);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(25, 18);
            this.label52.TabIndex = 50;
            this.label52.Text = "I4";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label50.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(20, 86);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(26, 18);
            this.label50.TabIndex = 44;
            this.label50.Text = "I9";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label47.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(272, 86);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(32, 18);
            this.label47.TabIndex = 54;
            this.label47.Text = "I11";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label40.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(408, 56);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(26, 18);
            this.label40.TabIndex = 56;
            this.label40.Text = "I8";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label16.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(401, 86);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(33, 18);
            this.label16.TabIndex = 58;
            this.label16.Text = "I12";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(372, 26);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(18, 18);
            this.label31.TabIndex = 71;
            this.label31.Text = "+";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(372, 56);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(18, 18);
            this.label30.TabIndex = 72;
            this.label30.Text = "+";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(372, 86);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(18, 18);
            this.label29.TabIndex = 73;
            this.label29.Text = "+";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(242, 26);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(18, 18);
            this.label34.TabIndex = 74;
            this.label34.Text = "+";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(112, 26);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(18, 18);
            this.label49.TabIndex = 77;
            this.label49.Text = "+";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(242, 56);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(18, 18);
            this.label13.TabIndex = 78;
            this.label13.Text = "+";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(112, 56);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(18, 18);
            this.label11.TabIndex = 79;
            this.label11.Text = "+";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(242, 86);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(18, 18);
            this.label17.TabIndex = 80;
            this.label17.Text = "+";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(112, 86);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(18, 18);
            this.label15.TabIndex = 81;
            this.label15.Text = "+";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(50, 23);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(44, 24);
            this.textBox9.TabIndex = 25;
            this.textBox9.Text = "0";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(180, 23);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(44, 24);
            this.textBox10.TabIndex = 82;
            this.textBox10.Text = "0";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(310, 23);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(44, 24);
            this.textBox11.TabIndex = 83;
            this.textBox11.Text = "0";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(439, 23);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(44, 24);
            this.textBox12.TabIndex = 84;
            this.textBox12.Text = "0";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(50, 53);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(44, 24);
            this.textBox16.TabIndex = 85;
            this.textBox16.Text = "0";
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(180, 53);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(44, 24);
            this.textBox15.TabIndex = 86;
            this.textBox15.Text = "0";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(310, 53);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(44, 24);
            this.textBox14.TabIndex = 87;
            this.textBox14.Text = "0";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(439, 53);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(44, 24);
            this.textBox13.TabIndex = 88;
            this.textBox13.Text = "0";
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(50, 83);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(44, 24);
            this.textBox20.TabIndex = 89;
            this.textBox20.Text = "0";
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(180, 83);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(44, 24);
            this.textBox19.TabIndex = 90;
            this.textBox19.Text = "0";
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(310, 83);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(44, 24);
            this.textBox18.TabIndex = 91;
            this.textBox18.Text = "0";
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(439, 83);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(44, 24);
            this.textBox17.TabIndex = 92;
            this.textBox17.Text = "0";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBox17);
            this.groupBox3.Controls.Add(this.textBox18);
            this.groupBox3.Controls.Add(this.textBox19);
            this.groupBox3.Controls.Add(this.textBox20);
            this.groupBox3.Controls.Add(this.textBox13);
            this.groupBox3.Controls.Add(this.textBox14);
            this.groupBox3.Controls.Add(this.textBox15);
            this.groupBox3.Controls.Add(this.textBox16);
            this.groupBox3.Controls.Add(this.textBox12);
            this.groupBox3.Controls.Add(this.textBox11);
            this.groupBox3.Controls.Add(this.textBox10);
            this.groupBox3.Controls.Add(this.textBox9);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.label49);
            this.groupBox3.Controls.Add(this.label34);
            this.groupBox3.Controls.Add(this.label29);
            this.groupBox3.Controls.Add(this.label30);
            this.groupBox3.Controls.Add(this.label31);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.label40);
            this.groupBox3.Controls.Add(this.label47);
            this.groupBox3.Controls.Add(this.label50);
            this.groupBox3.Controls.Add(this.label52);
            this.groupBox3.Controls.Add(this.label54);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label39);
            this.groupBox3.Controls.Add(this.label36);
            this.groupBox3.Controls.Add(this.label37);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(15, 45);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(500, 117);
            this.groupBox3.TabIndex = 17;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Insira os valores:";
            this.groupBox3.Visible = false;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(242, 26);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(18, 18);
            this.label23.TabIndex = 109;
            this.label23.Text = "+";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(112, 26);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(18, 18);
            this.label22.TabIndex = 110;
            this.label22.Text = "+";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(372, 86);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(18, 18);
            this.label24.TabIndex = 108;
            this.label24.Text = "+";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(242, 56);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(18, 18);
            this.label21.TabIndex = 111;
            this.label21.Text = "+";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(372, 56);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(18, 18);
            this.label25.TabIndex = 107;
            this.label25.Text = "+";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(112, 56);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(18, 18);
            this.label20.TabIndex = 112;
            this.label20.Text = "+";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(372, 26);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(18, 18);
            this.label26.TabIndex = 106;
            this.label26.Text = "+";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(242, 86);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(18, 18);
            this.label19.TabIndex = 113;
            this.label19.Text = "+";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label27.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(401, 86);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(33, 18);
            this.label27.TabIndex = 105;
            this.label27.Text = "I12";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(112, 86);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(18, 18);
            this.label18.TabIndex = 114;
            this.label18.Text = "+";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label28.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(408, 56);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(26, 18);
            this.label28.TabIndex = 104;
            this.label28.Text = "I8";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label32.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(272, 86);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(32, 18);
            this.label32.TabIndex = 103;
            this.label32.Text = "I11";
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(180, 23);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(44, 24);
            this.textBox31.TabIndex = 115;
            this.textBox31.Text = "0";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label33.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(20, 86);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(26, 18);
            this.label33.TabIndex = 100;
            this.label33.Text = "I9";
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(310, 23);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(44, 24);
            this.textBox30.TabIndex = 116;
            this.textBox30.Text = "0";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label35.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(408, 26);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(25, 18);
            this.label35.TabIndex = 102;
            this.label35.Text = "I4";
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(439, 23);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(44, 24);
            this.textBox29.TabIndex = 117;
            this.textBox29.Text = "0";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label38.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(141, 86);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(34, 18);
            this.label38.TabIndex = 101;
            this.label38.Text = "I10";
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(50, 53);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(44, 24);
            this.textBox28.TabIndex = 118;
            this.textBox28.Text = "0";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label41.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(278, 56);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(25, 18);
            this.label41.TabIndex = 99;
            this.label41.Text = "I7";
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(180, 53);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(44, 24);
            this.textBox27.TabIndex = 119;
            this.textBox27.Text = "0";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label48.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(279, 26);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(25, 18);
            this.label48.TabIndex = 98;
            this.label48.Text = "I3";
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(310, 53);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(44, 24);
            this.textBox26.TabIndex = 120;
            this.textBox26.Text = "0";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label51.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(149, 56);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(26, 18);
            this.label51.TabIndex = 97;
            this.label51.Text = "I6";
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(439, 53);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(44, 24);
            this.textBox25.TabIndex = 121;
            this.textBox25.Text = "0";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label53.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(20, 26);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(24, 18);
            this.label53.TabIndex = 94;
            this.label53.Text = "I1";
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(50, 83);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(44, 24);
            this.textBox24.TabIndex = 122;
            this.textBox24.Text = "0";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label55.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(19, 56);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(25, 18);
            this.label55.TabIndex = 96;
            this.label55.Text = "I5";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(180, 83);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(44, 24);
            this.textBox23.TabIndex = 123;
            this.textBox23.Text = "0";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label56.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(149, 26);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(25, 18);
            this.label56.TabIndex = 95;
            this.label56.Text = "I2";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(310, 83);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(44, 24);
            this.textBox22.TabIndex = 124;
            this.textBox22.Text = "0";
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(50, 23);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(44, 24);
            this.textBox32.TabIndex = 93;
            this.textBox32.Text = "0";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(439, 83);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(44, 24);
            this.textBox21.TabIndex = 125;
            this.textBox21.Text = "0";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label70.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.Location = new System.Drawing.Point(372, 146);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(18, 18);
            this.label70.TabIndex = 135;
            this.label70.Text = "+";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label69.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.Location = new System.Drawing.Point(242, 116);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(18, 18);
            this.label69.TabIndex = 136;
            this.label69.Text = "+";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label68.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.Location = new System.Drawing.Point(372, 116);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(18, 18);
            this.label68.TabIndex = 134;
            this.label68.Text = "+";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label67.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.Location = new System.Drawing.Point(112, 116);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(18, 18);
            this.label67.TabIndex = 137;
            this.label67.Text = "+";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label66.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.Location = new System.Drawing.Point(242, 146);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(18, 18);
            this.label66.TabIndex = 138;
            this.label66.Text = "+";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label65.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(401, 146);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(35, 18);
            this.label65.TabIndex = 133;
            this.label65.Text = "I20";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label64.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(112, 146);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(18, 18);
            this.label64.TabIndex = 139;
            this.label64.Text = "+";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label62.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.Location = new System.Drawing.Point(271, 146);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(34, 18);
            this.label62.TabIndex = 131;
            this.label62.Text = "I19";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label60.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(141, 146);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(34, 18);
            this.label60.TabIndex = 130;
            this.label60.Text = "I18";
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(50, 113);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(44, 24);
            this.textBox40.TabIndex = 140;
            this.textBox40.Text = "0";
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(180, 113);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(44, 24);
            this.textBox39.TabIndex = 141;
            this.textBox39.Text = "0";
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(310, 113);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(44, 24);
            this.textBox38.TabIndex = 142;
            this.textBox38.Text = "0";
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(439, 113);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(44, 24);
            this.textBox37.TabIndex = 143;
            this.textBox37.Text = "0";
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(50, 143);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(44, 24);
            this.textBox36.TabIndex = 144;
            this.textBox36.Text = "0";
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(180, 143);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(44, 24);
            this.textBox35.TabIndex = 145;
            this.textBox35.Text = "0";
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(310, 143);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(44, 24);
            this.textBox34.TabIndex = 146;
            this.textBox34.Text = "0";
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(439, 143);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(44, 24);
            this.textBox33.TabIndex = 147;
            this.textBox33.Text = "0";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label59.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(401, 116);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(34, 18);
            this.label59.TabIndex = 150;
            this.label59.Text = "I16";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label58.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(272, 116);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(33, 18);
            this.label58.TabIndex = 149;
            this.label58.Text = "I15";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label57.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(141, 116);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(33, 18);
            this.label57.TabIndex = 148;
            this.label57.Text = "I14";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label63.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.Location = new System.Drawing.Point(12, 146);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(33, 18);
            this.label63.TabIndex = 151;
            this.label63.Text = "I17";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.label61.Font = new System.Drawing.Font("Georgia", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(12, 116);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(33, 18);
            this.label61.TabIndex = 152;
            this.label61.Text = "I13";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label61);
            this.groupBox4.Controls.Add(this.label63);
            this.groupBox4.Controls.Add(this.label57);
            this.groupBox4.Controls.Add(this.label58);
            this.groupBox4.Controls.Add(this.label59);
            this.groupBox4.Controls.Add(this.textBox33);
            this.groupBox4.Controls.Add(this.textBox34);
            this.groupBox4.Controls.Add(this.textBox35);
            this.groupBox4.Controls.Add(this.textBox36);
            this.groupBox4.Controls.Add(this.textBox37);
            this.groupBox4.Controls.Add(this.textBox38);
            this.groupBox4.Controls.Add(this.textBox39);
            this.groupBox4.Controls.Add(this.textBox40);
            this.groupBox4.Controls.Add(this.label60);
            this.groupBox4.Controls.Add(this.label62);
            this.groupBox4.Controls.Add(this.label64);
            this.groupBox4.Controls.Add(this.label65);
            this.groupBox4.Controls.Add(this.label66);
            this.groupBox4.Controls.Add(this.label67);
            this.groupBox4.Controls.Add(this.label68);
            this.groupBox4.Controls.Add(this.label69);
            this.groupBox4.Controls.Add(this.label70);
            this.groupBox4.Controls.Add(this.textBox21);
            this.groupBox4.Controls.Add(this.textBox32);
            this.groupBox4.Controls.Add(this.textBox22);
            this.groupBox4.Controls.Add(this.label56);
            this.groupBox4.Controls.Add(this.textBox23);
            this.groupBox4.Controls.Add(this.label55);
            this.groupBox4.Controls.Add(this.textBox24);
            this.groupBox4.Controls.Add(this.label53);
            this.groupBox4.Controls.Add(this.textBox25);
            this.groupBox4.Controls.Add(this.label51);
            this.groupBox4.Controls.Add(this.textBox26);
            this.groupBox4.Controls.Add(this.label48);
            this.groupBox4.Controls.Add(this.textBox27);
            this.groupBox4.Controls.Add(this.label41);
            this.groupBox4.Controls.Add(this.textBox28);
            this.groupBox4.Controls.Add(this.label38);
            this.groupBox4.Controls.Add(this.textBox29);
            this.groupBox4.Controls.Add(this.label35);
            this.groupBox4.Controls.Add(this.textBox30);
            this.groupBox4.Controls.Add(this.label33);
            this.groupBox4.Controls.Add(this.textBox31);
            this.groupBox4.Controls.Add(this.label32);
            this.groupBox4.Controls.Add(this.label28);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.label27);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.label26);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.label25);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.label24);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(15, 45);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(500, 184);
            this.groupBox4.TabIndex = 18;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Insira os valores:";
            this.groupBox4.Visible = false;
            // 
            // Malha
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(534, 65);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label72);
            this.Controls.Add(this.label71);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Location = new System.Drawing.Point(300, 300);
            this.MaximizeBox = false;
            this.Name = "Malha";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Malha";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.GroupBox groupBox4;
    }
}