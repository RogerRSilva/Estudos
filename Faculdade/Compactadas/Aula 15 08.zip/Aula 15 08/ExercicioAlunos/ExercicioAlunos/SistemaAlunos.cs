﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExercicioAlunos
{
    public partial class SistemaAlunos : Form
    {
        //váriaveis globais que armazenam nome e as notas
        public static string nome, nota1, nota2, nota3;

        //inicia o formulário
        public SistemaAlunos()
        {
            InitializeComponent();
        }

        //armazena a primeira nota
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            nota1 = textBox1.Text.ToString();
        }

        //armazena a segunda nota
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            nota2 = textBox2.Text.ToString();
        }

        //armazena a terceira nota
        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            nota3 = textBox3.Text.ToString();
        }

        //armazena o nome
        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            nome = textBox4.Text.ToString();
        }

        //Quando o botão "Calcular" é pressionado, é instanciada a classe
        private void button1_Click(object sender, EventArgs e)
        {
            VerificaCalcula();
        }
       
        //Quando o botão "Sair" é pressionado, fecha o aplicativo
        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //Quando o botão "Limpar" é pressionado, limpa todos os campos
        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
        }

        //classe que verifica os dados inseridos e realiza o cálculo
        void VerificaCalcula()
        {
            try
            {
                //converte as notas para float
                float notaUm = float.Parse(textBox1.Text);
                float notaDois = float.Parse(textBox2.Text);
                float notaTres = float.Parse(textBox3.Text);

                //calcula a media
                float media = (notaUm + notaDois + notaTres) / 3;

                //mostra as informações processadas para o usuário
                MessageBox.Show("A média do Aluno " + nome + " é: " + media.ToString("0.0"), "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Information); 
            }
            //trata a exceção, caso o valor inserido nos campos de nota não sejam numéricos
            catch (FormatException)
            {
                //informa o usuário do erro e limpa os campos
                MessageBox.Show("Valor Inválido", "ERRO!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
            }
        }
    }
}
